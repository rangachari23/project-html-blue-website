#samples of Docker AWS DevOps Project

| Language | Platform | Author |
| -------- | --------|--------|
| HTML |  Cloud Web App, Virtual Machine| |

# Sample HTML website 

Sample HTML/CSS web app that you can deploy to Azure. 


